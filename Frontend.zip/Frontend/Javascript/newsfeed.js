function showUser() {

		getSubs();
		getFollowers();
		updatePortfolio () 
}