/*!CK:3383421149!*//*1415165845,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["OEIZN"]); }

__d("ChatSidebarDropdownConstants",[],function(a,b,c,d,e,f){var g={SOUND:'sound',ADVANCED_SETTINGS:'advanced_settings',TURN_OFF_DIALOG:'turn_off_dialog',CLOSE_ALL_TABS:'close_all_tabs',SIDEBAR:'sidebar',ONLINE:'online',PAUSE:'pause',SHOW_APPS:'show_apps',HIDE_APPS:'hide_apps',SHOW_TICKER:'show_ticker',HIDE_TICKER:'hide_ticker'};e.exports=g;},null);