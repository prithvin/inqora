/*!CK:3500758222!*//*1425268892,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["1cdJ7"]); }

__d("SuggestionLoggingUserActions",[],function(a,b,c,d,e,f){e.exports={POST_WITH_SUGG:"post-sugg",POST_WO_SUGG:"post-no-sugg",IMPRESSION:"impression",DEIMPRESSION:"deimpression",ADD:"add",XOUT:"x-out",CLICK_TAGGER:"og-tagger-click"};},null);