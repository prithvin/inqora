/*!CK:1612230068!*//*1382426753,178191153*/

if (self.CavalryLogger) { CavalryLogger.start_js(["f0pxh"]); }

__d("legacy:ComposerXControllerBootload",["ComposerXController"],function(a,b,c,d){b('ComposerXController');},3);