/*!CK:1442166406!*//*1412890920,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["8eJ2b"]); }

__d("legacy:PhotoSnowliftAds",["PhotoSnowliftAds"],function(a,b,c,d){a.PhotoSnowliftAds=b('PhotoSnowliftAds');},3);