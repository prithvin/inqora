/*!CK:1072858542!*//*1401157982,178183207*/

if (self.CavalryLogger) { CavalryLogger.start_js(["XtuGt"]); }

__d("ComposerXStatusAttachmentBootloader",["ComposerXBootloadStatusAttachment","ComposerXMentionsInputReset","ComposerXPrivacyWidgetReset","MentionsInput","MentionsTypeaheadAreaView","emptyFunction"],function(a,b,c,d,e,f){b('ComposerXBootloadStatusAttachment');b('ComposerXMentionsInputReset');b('ComposerXPrivacyWidgetReset');b('MentionsInput');b('MentionsTypeaheadAreaView');e.exports={emptyFunction:b('emptyFunction')};},null);