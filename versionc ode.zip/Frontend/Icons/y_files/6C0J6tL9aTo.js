/*!CK:2407092433!*//*1425268892,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["7D3rV"]); }

__d("SuggestionLoggingParamNames",[],function(a,b,c,d,e,f){e.exports={ERASED:"erased",USER_ACTION:"user_action",CONFIG:"config",SUGGESTION:"suggestion",MECHANISM:"mechanism",COMPOSER_SESSION_ID:"csid"};},null);