/*!CK:3025296077!*//*1418945488,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["Nwarm"]); }

__d("legacy:LayerDestroyOnHide",["LayerDestroyOnHide"],function(a,b,c,d){a.LayerDestroyOnHide=b('LayerDestroyOnHide');},3);
__d("legacy:LayerHideOnBlur",["LayerHideOnBlur"],function(a,b,c,d){a.LayerHideOnBlur=b('LayerHideOnBlur');},3);
__d("legacy:LegacyContextualDialog",["LegacyContextualDialog"],function(a,b,c,d){a.LegacyContextualDialog=b('LegacyContextualDialog');},3);