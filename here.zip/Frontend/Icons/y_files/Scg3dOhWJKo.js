/*!CK:1246108662!*//*1422244445,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["fQ4Wm"]); }

__d("XStructuredSuggestionController",["XController"],function(a,b,c,d,e,f){e.exports=b("XController").create("\/structured_suggestion\/",{config_name:{type:"String",required:true},composer_state:{type:"StringToStringMap"},supported_presentation:{type:"EnumVector",required:true,enumType:{member:0}},extra_data:{type:"StringToStringMap"},csid:{type:"String"}});},null);