/*!CK:1562203671!*//*1421682599,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["kZVeB"]); }

__d("LitestandComposerPublisher",["Arbiter"],function(a,b,c,d,e,f,g){f.publish=function(h,i,j){g.inform('LitestandComposer/publish',{composer_id:h,content_id:j,markup:i});};},null);
__d("ShareLikeFooterContext",[],function(a,b,c,d,e,f){var g={STREAM:'stream',TICKER:'ticker',TIMELINE:'timeline',LITESTAND:'litestand'};e.exports=g;},null);