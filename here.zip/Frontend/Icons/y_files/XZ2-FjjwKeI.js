/*!CK:1998059997!*//*1387556477,178191129*/

if (self.CavalryLogger) { CavalryLogger.start_js(["Zkght"]); }

__d("legacy:photos-constants",["PhotosConst"],function(a,b,c,d){a.PhotosConst=b('PhotosConst');},3);
__d("legacy:PhotoTagger",["PhotoTagger"],function(a,b,c,d){a.PhotoTagger=b('PhotoTagger');},3);