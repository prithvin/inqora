/*!CK:3720958409!*//*1422244381,*/

if (self.CavalryLogger) { CavalryLogger.start_js(["JoedA"]); }

__d("XChatMiniSidebarNUXSeenController",["XController"],function(a,b,c,d,e,f){e.exports=b("XController").create("\/chat\/mini_sidebar_nux_seen\/",{});},null);